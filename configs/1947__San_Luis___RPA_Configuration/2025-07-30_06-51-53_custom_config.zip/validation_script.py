# Validation Script - PDF Data Processing
form_variables = ["customer","check","sign"]

# Get expected values from dropdowns
expected_values = {}

# Text field - user types customer
expected_values['customer'] = input_data.get('customer', '')

# Checkbox field - user selects from dropdown
check_selection = input_data.get('check', '')
if check_selection == 'checked':
    expected_values['check'] = 'checked'
else:
    expected_values['check'] = 'unchecked'

# Signature field - user selects from dropdown
sign_selection = input_data.get('sign', '')
if sign_selection == 'signed':
    expected_values['sign'] = 'signed'
else:
    expected_values['sign'] = 'blank'