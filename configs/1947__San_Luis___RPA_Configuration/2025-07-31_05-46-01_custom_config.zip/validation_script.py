# Validation Script - PDF Data Processing
form_variables = ["sign","buyerintial"]

# Get expected values from dropdowns
expected_values = {}

# Signature field - user selects from dropdown
sign_selection = input_data.get('sign', '')
if sign_selection == 'signed':
    expected_values['sign'] = 'signed'
else:
    expected_values['sign'] = 'blank'

# Signature field - user selects from dropdown
buyerintial_selection = input_data.get('buyerintial', '')
if buyerintial_selection == 'signed':
    expected_values['buyerintial'] = 'signed'
else:
    expected_values['buyerintial'] = 'blank'