# Validation Script - PDF Data Processing
form_variables = ["sign"]


expected_values = {}

# Signature field - user selects from dropdown
sign_selection = input_data.get('sign', '')
if sign_selection == 'signed':
    expected_values['sign'] = 'signed'
else:
    expected_values['sign'] = 'blank'