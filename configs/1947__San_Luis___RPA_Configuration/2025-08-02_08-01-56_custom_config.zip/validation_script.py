# Validation Script - PDF Data Processing
form_variables = ["q1"]

# Get expected values from dropdowns
expected_values = {}

# Text field - user types q1
expected_values['q1'] = input_data.get('q1', '')

if not expected_values['q1'].strip():
    print(f"Warning: q1 is empty")