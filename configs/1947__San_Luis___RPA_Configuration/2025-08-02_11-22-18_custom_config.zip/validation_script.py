# Validation Script - PDF Data Processing
form_variables = ["q1","q2"]

# Get expected values from dropdowns
expected_values = {}

# Text field - user types q1
expected_values['q1'] = input_data.get('q1', '')

# Text field - user types q2
expected_values['q2'] = input_data.get('q2', '')