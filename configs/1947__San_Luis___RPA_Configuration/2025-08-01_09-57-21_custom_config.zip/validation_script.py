# Validation Script - PDF Data Processing
form_variables = ["customer"]

# Get expected values from dropdowns
expected_values = {}

# Text field - user types customer
expected_values['customer'] = input_data.get('customer', '')