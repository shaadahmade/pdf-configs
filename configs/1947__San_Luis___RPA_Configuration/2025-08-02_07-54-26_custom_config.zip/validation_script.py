# Validation Script - PDF Data Processing
form_variables = ["q1"]

# Get expected values from dropdowns
expected_values = {}

# Text field - user types q1
expected_values['q1'] = input_data.get('q1', '')