# Validation Script - PDF Data Processing
form_variables = ["q2","q1"]

# Get expected values from dropdowns
expected_values = {}

# Checkbox field - user selects from dropdown
q2_selection = input_data.get('q2', '')
if q2_selection == 'checked':
    expected_values['q2'] = 'checked'
else:
    expected_values['q2'] = 'unchecked'

# Signature field - user selects from dropdown
q1_selection = input_data.get('q1', '')
if q1_selection == 'signed':
    expected_values['q1'] = 'signed'
else:
    expected_values['q1'] = 'blank'