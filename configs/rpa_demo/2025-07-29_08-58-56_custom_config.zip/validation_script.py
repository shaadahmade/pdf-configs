# Validation Script - PDF Data Processing
form_variables = ['name', 'checkbox', 'signature']

# Get expected values from dropdowns
expected_values = {}

# Text field - user types name
expected_values['customer'] = input_data.get('name', '')

# Checkbox field - user selects from dropdown
checkbox_selection = input_data.get('checkbox')
if checkbox_selection == 'checked':
    expected_values['check'] = 'Checked'
else:
    expected_values['check'] = 'Unchecked'


signature_selection = input_data.get('signature')
if signature_selection == 'signed':
    expected_values['sign'] = 'Signed'
else:
    expected_values['sign'] = 'Blank'