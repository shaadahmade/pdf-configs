# Script 1 - PDF Data Processing
import json

def process_pdf_data(config):
    """Process PDF configuration data"""
    print(f"Processing: {config.get('pdf_name', 'Unknown')}")

    # Your processing logic here
    for page_num, page_data in config.get('pages', {}).items():
        fields = page_data.get('fields', [])
        print(f"Page {page_num}: {len(fields)} fields")

    return config

# Example usage
if __name__ == "__main__":
    with open('config.json', 'r') as f:
        config = json.load(f)
    result = process_pdf_data(config)