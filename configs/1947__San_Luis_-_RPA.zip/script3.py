# Script 3 - Form Generation
import json

def generate_form_template(config):
    """Generate form template from config"""
    template = {
        'form_name': config.get('pdf_name', 'form'),
        'fields': {}
    }

    for page_num, page_data in config.get('pages', {}).items():
        for field in page_data.get('fields', []):
            template['fields'][field['name']] = {
                'type': field['type'],
                'page': int(page_num),
                'coordinates': field['coordinates'],
                'value': ''
            }

    return template