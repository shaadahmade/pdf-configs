form_variables = [
    'price_per_unit',
    'quantity', 
    'tax_rate',
    'discount_amount'
]