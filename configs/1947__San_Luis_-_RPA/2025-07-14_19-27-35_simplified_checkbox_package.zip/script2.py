expected_values={ 
    'buyer1': BUYER1 , 
    'BUYER2': BUYER2 , 
    'PURCHASE': PURCHASE ,
    'DP_PERCENTAGE':DP_PERCENTAGE, 
    'DP':(PURCHASE * DP_PERCENTAGE)/100,
    'allBuyers': BUYER1 + ',' + BUYER2
}