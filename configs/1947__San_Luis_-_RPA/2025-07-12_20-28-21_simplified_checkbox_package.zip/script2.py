expected_values = {
    'user1': username,
    'user2': username
}