form_variables = ['buyer1_page1']

expected_values = {}
expected_values['buyer1'] = form_variables["buyer1_page1"]