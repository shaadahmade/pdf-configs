matches = []
mismatches = []

buyer1 = expected_values['buyer1']
buyer2 = expected_values['BUYER2']
purchase = expected_values['PURCHASE']
dp_percent = expected_values['DP_PERCENTAGE']
dp = expected_values['DP']
allBuyers = expected_values['allBuyers']

if buyer1 == af_BUYER1:
    matches.append(create_result_entry('buyer1',buyer1, userInfo, True))

else:
    mismatches.append(create_result_entry('buyer1', buyer1, userInfo, False))

if buyer2 == af_BUYER2:
    matches.append(create_result_entry('buyer2', buyer2, userInfo, True))

else: 
    mismatches.append(create_result_entry('buyer2', buyer2, userInfo, False))

if purchase == af_PURCHASE_PRICE:
    matches.append(create_result_entry('PURCHASE', purchase, userInfo, True))
    
else: 
    mismatches.append(create_result_entry('PURCHASE', purchase, userInfo, False))

if dp_percent == af_DP_PERCENTAGE:
    matches.append(create_result_entry('DP_PERCENTAGE', dp_percent, userInfo, True))

else: 
    mismatches.append(create_result_entry('DP_PERCENTAGE', dp_percent, userInfo, False))

if dp == af_DP:
    matches.append(create_result_entry('DP', dp, userInfo, True))

else: 
    mismatches.append(create_result_entry('DP', dp, userInfo, False))

if allBuyers == af_ALLBUYERS:
    matches.append(create_result_type('allBuyers', allBuyers, userInfo, True))

else: 
    mismatches.append(create_result_type('allBuyers', allBuyers, userInfo, False))
 validation_results = {
    'matches': matches,
    'mismatches': mismatches,
    'summary': calculate_summary(matches, mismatches)
}