form_variables=[
    'customer','check','sign'

]


expected_values={

}

expected_values['customer'] = input_data.get('customer','')

is_signature=input_data.get('sign')
if is_signature == 'signed':
    expected_values['sign']='signed'
else :
   expected_values['sign']='blank'    

is_checked=input_data.get('check')
if is_checked == 'checked':
    expected_values['check']='checked'
else :
   expected_values['check']='unchecked'