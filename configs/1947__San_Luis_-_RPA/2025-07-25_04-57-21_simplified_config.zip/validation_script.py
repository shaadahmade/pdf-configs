form_variables = ['buyer1_page1']


expected_values = {}
expected_values['buyer1'] = input_data.get("buyer1_page1", "")