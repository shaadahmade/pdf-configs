dre_ex = dre



expected_values={
    'page1_buyer': buyer,
    'page1_dre': dre_ex

}