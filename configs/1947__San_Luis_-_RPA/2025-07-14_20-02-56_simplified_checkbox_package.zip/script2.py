dp_percentage = float(DP_PERCENTAGE)
PRICE =float(PURCHASE_PRICE)
dp =  (PRICE * dp)/100 


expected_values={ 
    'buyer1': BUYER1 , 
    'BUYER2': BUYER2 , 
    'PURCHASE': PRICE ,
    'DP_PERCENTAGE':dp_percentage , 
    'DP':dp,
    'allBuyers': BUYER1 + ','+'' + BUYER2
}