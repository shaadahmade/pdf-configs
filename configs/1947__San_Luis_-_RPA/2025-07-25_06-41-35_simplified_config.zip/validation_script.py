form_variables = ['name', 'checkbox1', 'signature1']

# Get expected values from dropdowns
expected_values = {}

# Text field - user types name
expected_values['customer'] = input_data.get('name', '')

# Checkbox field - user selects from dropdown
checkbox_selection = input_data.get('checkbox1', '')
if checkbox_selection == 'checked':
    expected_values['check'] = 'checked'
else:
    expected_values['check'] = 'unchecked'

# Signature field - user selects from dropdown  
signature_selection = input_data.get('signature1', '')
if signature_selection == 'signed':
    expected_values['sign'] = 'signed'
else:
    expected_values['sign'] = 'blank'