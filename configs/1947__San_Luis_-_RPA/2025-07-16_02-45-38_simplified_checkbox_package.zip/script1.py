def gok (fsdsdd):
    sdadsdsad
    sdff