form_variables=[
    'customer','check','sign'

]


expected_values={

}

expected_values['customer'] = input_data.get('customer','')

is_signature=input_data.get('sign')
if is_signature == 'Signed':
    expected_values['sign']='Signed'
else :
   expected_values['sign']='Blank'    

is_checked=input_data.get('check')
if is_checked == 'Checked':
    expected_values['check']='Checked'
else :
   expected_values['check']='Unchecked'