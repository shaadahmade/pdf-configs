form_variables = {
    "buyer1_page1": "Enter buyer name",
    
}

# Use the values directly as expected values
expected_values = {}
expected_values['buyer1'] = form_variables["buyer1_page1"]