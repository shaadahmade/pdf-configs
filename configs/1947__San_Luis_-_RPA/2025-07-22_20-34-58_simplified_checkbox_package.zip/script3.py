matches=[]
mismatches=[]

buyer_1 = expected_values['page1_buyer']
agent_dre = expected_values['page1_dre']

if buyer_1 == af_page1_buyer:
    matches.append(create_result_entry('page1_buyer',buyer_1,page1_buyer_info,True))
else:
     mismatches.append(create_result_entry('page1_buyer',buyer_1,page1_buyer_info,False))


if agent_dre == af_page1_dre:
    matches.append(create_result_entry('page1_dre',agent_dre,page1_dre_info,True))
else:
     mismatches.append(create_result_entry('page1_dre',agent_dre,page1_dre_info,False))
validation_results=
{
    'matches':matches
    ,'mismatches':mismatches
    ,'summary':calculate_summary(matches,mismatches)
}