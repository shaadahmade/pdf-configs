dre_ex = int(str(dre))+1



expected_values={
    'page1_buyer': buyer,
    'page1_dre': str(dre_ex)

}