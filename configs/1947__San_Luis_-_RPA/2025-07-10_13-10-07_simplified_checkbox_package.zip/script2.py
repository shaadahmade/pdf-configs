# script2.py - Calculate expected values from user input
# Variables automatically available: unit_price, quantity, tax_rate, discount_amount

subtotal = unit_price * quantity
tax_amount = subtotal * (tax_rate / 100)
total = subtotal + tax_amount - discount_amount

expected_values = {
    'invoice_subtotal': f"${subtotal:.2f}",
    'tax_amount': f"${tax_amount:.2f}",
    'total_amount': f"${total:.2f}",
    'item_count': str(int(quantity))
}