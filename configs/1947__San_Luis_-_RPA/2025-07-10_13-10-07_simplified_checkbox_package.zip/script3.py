# script3.py - Custom validation with tolerances and special rules
import math

# Available: expected_values, actual_fields, helper functions
# Helper functions: create_mismatch(), create_match(), get_field_info()

validation_results = {
    'mismatches': [],
    'matches': []
}

# Custom validation for each field
for field_name, expected_value in expected_values.items():
    # Get actual value from PDF
    actual_value = None
    for page_num, page_fields in actual_fields.items():
        if field_name in page_fields:
            actual_value = page_fields[field_name]['value']
            break
    
    if actual_value is None:
        # Field not found in PDF
        validation_results['mismatches'].append(
            create_mismatch(field_name, expected_value, "NOT FOUND", "Field missing from PDF")
        )
        continue
    
    # Custom validation logic by field type
    if field_name in ['invoice_subtotal', 'tax_amount', 'total_amount']:
        # Money fields - allow small rounding differences
        expected_num = float(expected_value.replace('$', '').replace(',', ''))
        try:
            actual_num = float(actual_value.replace('$', '').replace(',', ''))
            difference = abs(expected_num - actual_num)
            
            if difference <= 0.02:  # 2 cent tolerance
                validation_results['matches'].append(
                    create_match(field_name, expected_value, actual_value)
                )
            else:
                reason = f"Amount differs by ${difference:.2f} (tolerance: $0.02)"
                validation_results['mismatches'].append(
                    create_mismatch(field_name, expected_value, actual_value, reason)
                )
        except ValueError:
            validation_results['mismatches'].append(
                create_mismatch(field_name, expected_value, actual_value, "Invalid number format")
            )
    
    elif field_name == 'item_count':
        # Exact match for quantities
        if str(expected_value) == str(actual_value):
            validation_results['matches'].append(
                create_match(field_name, expected_value, actual_value)
            )
        else:
            validation_results['mismatches'].append(
                create_mismatch(field_name, expected_value, actual_value, "Quantity must match exactly")
            )
    
    else:
        # Default string comparison with case insensitive
        if str(expected_value).lower().strip() == str(actual_value).lower().strip():
            validation_results['matches'].append(
                create_match(field_name, expected_value, actual_value)
            )
        else:
            validation_results['mismatches'].append(
                create_mismatch(field_name, expected_value, actual_value, "Text does not match")
            )