# script1.py - Just declare what user should input
form_variables = [
    'unit_price',
    'quantity', 
    'tax_rate',
    'discount_amount'
]