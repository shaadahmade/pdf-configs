# Validation Script - PDF Data Processing
import json

def process_pdf_data(config):
    """Process PDF configuration data"""
    print(f"Processing: {config.get('pdf_name', 'Unknown')}")

    # Your processing logic here
    for page_num, page_data in config.get('pages', {}).items():
        fields = page_data.get('fields', [])
        print(f"Page {page_num}: {len(fields)} fields")

        # Process each field
        for field in fields:
            field_name = field['name']
            field_type = field['type']
            coordinates = field['coordinates']

            print(f"  - {field_name} ({field_type}): {coordinates}")

            # Handle different field types
            if field_type == 'checkbox':
                # Simple checkbox processing - just coordinates
                coords = coordinates.split(',')
                x1, y1, x2, y2 = map(float, coords)
                print(f"    Checkbox area: ({x1}, {y1}) to ({x2}, {y2})")

            elif field_type == 'text':
                # Text field processing
                print(f"    Text field for extraction")

            elif field_type == 'signature':
                # Signature field processing
                print(f"    Signature field for capture")

    return config

def extract_field_coordinates(config):
    """Extract field coordinates from config"""
    fields = []

    for page_num, page_data in config.get('pages', {}).items():
        for field in page_data.get('fields', []):
            coords = field['coordinates'].split(',')
            fields.append({
                'name': field['name'],
                'type': field['type'],
                'page': int(page_num),
                'x1': float(coords[0]),
                'y1': float(coords[1]),
                'x2': float(coords[2]),
                'y2': float(coords[3])
            })

    return fields

def generate_form_template(config):
    """Generate form template from config"""
    template = {
        'form_name': config.get('pdf_name', 'form'),
        'fields': {}
    }

    for page_num, page_data in config.get('pages', {}).items():
        for field in page_data.get('fields', []):
            template['fields'][field['name']] = {
                'type': field['type'],
                'page': int(page_num),
                'coordinates': field['coordinates'],
                'value': ''
            }

    return template

# Example usage
if __name__ == "__main__":
    # Load and process configuration
    with open('config.json', 'r') as f:
        config = json.load(f)

    # Process the PDF data
    result = process_pdf_data(config)

    # Extract coordinates
    coordinates = extract_field_coordinates(config)

    # Generate form template
    template = generate_form_template(config)

    print(f"Processed {len(coordinates)} fields")