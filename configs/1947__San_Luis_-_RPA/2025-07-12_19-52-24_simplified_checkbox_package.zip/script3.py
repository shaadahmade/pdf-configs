matches = []
mismatches = []
total_fields = 0

# Go through each expected field
for field_name, expected_value in expected_values.items():
    total_fields += 1
    
    # Find this field in the actual PDF data
    actual_value = None
    field_page = None
    field_coordinates = None
    field_type = None
    
    # Search all pages for this field
    for page_num, page_fields in actual_fields.items():
        if field_name in page_fields:
            actual_value = page_fields[field_name]['value']
            field_page = page_num
            field_coordinates = page_fields[field_name]['coordinates']
            field_type = page_fields[field_name]['type']
            break
    
    # Check if they match (case insensitive)
    if actual_value:
        is_match = str(expected_value).lower().strip() == str(actual_value).lower().strip()
    else:
        is_match = False  # Field not found in PDF
    
    # Create result entry
    result_entry = {
        'field_name': field_name,
        'field_type': field_type or 'text',
        'page': field_page or 'not_found',
        'coordinates': field_coordinates or 'unknown',
        'expected': expected_value,
        'actual': actual_value or 'FIELD NOT FOUND',
        'match': is_match
    }
    
    # Add to appropriate list
    if is_match:
        matches.append(result_entry)
    else:
        mismatches.append(result_entry)

# Calculate summary
matching_fields = len(matches)
mismatched_fields = len(mismatches)
accuracy_percentage = round((matching_fields / total_fields * 100), 2) if total_fields > 0 else 0

# Final validation results
validation_results = {
    'matches': matches,
    'mismatches': mismatches,
    'summary': {
        'total_fields': total_fields,
        'matching_fields': matching_fields,
        'mismatched_fields': mismatched_fields,
        'accuracy_percentage': accuracy_percentage
    }
}