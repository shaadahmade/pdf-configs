expected_values = {
    # Page 1 username fields
    'user_name_page1': username,
    'username_field1': username,
    
    # Page 2 username fields  
    'user_name_page2': username,
    'username_header': username,
    
    # Page 3 username fields
    'user_name_page3': username,
    'signature_name': username,
    'account_name': username,
    
    # Any other username-related fields
    'full_name': username,
    'account_holder': username
}