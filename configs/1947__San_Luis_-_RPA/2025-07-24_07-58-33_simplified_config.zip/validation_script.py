form_variables = ['buyer1']

expected_values = {}
expected_values['page1_field1'] = form_variables["buyer1"]