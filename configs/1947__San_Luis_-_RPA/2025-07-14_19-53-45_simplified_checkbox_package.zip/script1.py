form_variables = [
    'BUYER1', 'BUYER2' , 'PURCHASE_PRICE', 'DP_PERCENTAGE'
]