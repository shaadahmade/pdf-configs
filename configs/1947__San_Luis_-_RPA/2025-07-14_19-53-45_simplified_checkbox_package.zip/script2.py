dp = float(DP_PERCENTAGE)
PRICE =float(PURCHASE_PRICE)

expected_values={ 
    'buyer1': BUYER1 , 
    'BUYER2': BUYER2 , 
    'PURCHASE': PRICE ,
    'DP_PERCENTAGE':dp , 
    'DP':float((PRICE * dp)/100),
    'allBuyers': BUYER1 + ', ' + BUYER2
}