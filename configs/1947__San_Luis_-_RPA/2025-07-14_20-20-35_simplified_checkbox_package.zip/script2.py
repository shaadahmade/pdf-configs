dp_percentage = float(DP_PERCENTAGE) / 100  # Convert percentage to decimal
price = float(PURCHASE_PRICE)
dp = price * dp_percentage  # Calculate down payment amount

expected_values = {
    'BUYER1': BUYER1,
    'BUYER2': BUYER2,
    'PURCHASE_PRICE': f"${price:,.2f}",  # Format as currency
    'DP_PERCENTAGE': f"{dp_percentage * 100:.1f}%",  # Format as percentage
    'DP': f"${dp:,.2f}",  # Format down payment as currency
    'ALLBUYERS': BUYER1 + ', ' + BUYER2  # Fixed spacing and concatenation
}