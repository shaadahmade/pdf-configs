matches = []
mismatches = []

# Get expected values
buyer1 = expected_values['BUYER1']
buyer2 = expected_values['BUYER2']
purchase = expected_values['PURCHASE_PRICE']
dp_percent = expected_values['DP_PERCENTAGE']
dp = expected_values['DP']
allBuyers = expected_values['ALLBUYERS']

# Fixed field name matching and info objects
if buyer1 == af_BUYER1:
    matches.append(create_result_entry('BUYER1', buyer1, BUYER1_info, True))
else:
    mismatches.append(create_result_entry('BUYER1', buyer1, BUYER1_info, False))

if buyer2 == af_BUYER2:
    matches.append(create_result_entry('BUYER2', buyer2, BUYER2_info, True))
else: 
    mismatches.append(create_result_entry('BUYER2', buyer2, BUYER2_info, False))

if purchase == af_PURCHASE_PRICE:
    matches.append(create_result_entry('PURCHASE_PRICE', purchase, PURCHASE_PRICE_info, True))
else: 
    mismatches.append(create_result_entry('PURCHASE_PRICE', purchase, PURCHASE_PRICE_info, False))

if dp_percent == af_DP_PERCENTAGE:
    matches.append(create_result_entry('DP_PERCENTAGE', dp_percent, DP_PERCENTAGE_info, True))
else: 
    mismatches.append(create_result_entry('DP_PERCENTAGE', dp_percent, DP_PERCENTAGE_info, False))

if dp == af_DP:
    matches.append(create_result_entry('DP', dp, DP_info, True))
else: 
    mismatches.append(create_result_entry('DP', dp, DP_info, False))

if allBuyers == af_ALLBUYERS:
    matches.append(create_result_entry('ALLBUYERS', allBuyers, ALLBUYERS_info, True))
else: 
    mismatches.append(create_result_entry('ALLBUYERS', allBuyers, ALLBUYERS_info, False))

# Final validation results
validation_results = {
    'matches': matches,
    'mismatches': mismatches,
    'summary': calculate_summary(matches, mismatches)
}