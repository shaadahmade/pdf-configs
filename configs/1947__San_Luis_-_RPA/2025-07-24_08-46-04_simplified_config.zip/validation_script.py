form_variables=[
    'page1_buyer'
]


expected_values={

}

expected_values['page1_buyer'] = form_variables["page1_buyer"]