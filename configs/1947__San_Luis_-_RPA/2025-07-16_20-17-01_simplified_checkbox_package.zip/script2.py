# Script 2 - Field Processing
import json

def extract_field_coordinates(config):
    """Extract field coordinates from config"""
    fields = []

    for page_num, page_data in config.get('pages', {}).items():
        for field in page_data.get('fields', []):
            coords = field['coordinates'].split(',')
            fields.append({
                'name': field['name'],
                'type': field['type'],
                'page': int(page_num),
                'x1': float(coords[0]),
                'y1': float(coords[1]),
                'x2': float(coords[2]),
                'y2': float(coords[3])
            })

    return fields