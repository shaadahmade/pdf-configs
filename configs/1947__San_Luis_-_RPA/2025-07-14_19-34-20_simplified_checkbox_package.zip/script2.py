expected_values={ 
    'buyer1': BUYER1 , 
    'BUYER2': BUYER2 , 
    'PURCHASE': float(PURCHASE) ,
    'DP_PERCENTAGE':float(DP_PERCENTAGE), 
    'DP':float((PURCHASE * DP_PERCENTAGE)/100),
    'allBuyers': BUYER1 + ',' + BUYER2
}