# script3.py - Simple validation using pre-parsed fields
matches = []
mismatches = []

# Get expected values
ef_user1 = expected_values['user1']
ef_user2 = expected_values['user2'] 
ef_agreement = expected_values['agreement_checkbox']
ef_signature = expected_values['signature_area']

# Direct comparisons (your preferred style: ef == af)
if ef_user1 == af_user1:
    matches.append(create_result_entry('user1', ef_user1, user1_info, True))
else:
    mismatches.append(create_result_entry('user1', ef_user1, user1_info, False))

if ef_user2 == af_user2:
    matches.append(create_result_entry('user2', ef_user2, user2_info, True))
else:
    mismatches.append(create_result_entry('user2', ef_user2, user2_info, False))

if ef_agreement == af_agreement_checkbox:
    matches.append(create_result_entry('agreement_checkbox', ef_agreement, agreement_checkbox_info, True))
else:
    mismatches.append(create_result_entry('agreement_checkbox', ef_agreement, agreement_checkbox_info, False))

if ef_signature == af_signature_area:
    matches.append(create_result_entry('signature_area', ef_signature, signature_area_info, True))
else:
    mismatches.append(create_result_entry('signature_area', ef_signature, signature_area_info, False))

# Final results
validation_results = {
    'matches': matches,
    'mismatches': mismatches,
    'summary': calculate_summary(matches, mismatches)
}