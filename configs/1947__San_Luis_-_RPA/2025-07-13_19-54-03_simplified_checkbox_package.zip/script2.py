expected_values = {
    'user1': username,
    'user2': username,
    'agreement_checkbox': 'checked',
    'signature_area': 'signed'
}