# script2.py
total = price * quantity
tax = total * (tax_rate / 100)
final_total = total + tax

expected_values = {
    'subtotal_field': f"${total:.2f}",
    'tax_field': f"${tax:.2f}", 
    'total_field': f"${final_total:.2f}"
}