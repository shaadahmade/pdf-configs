# script1.py
form_variables = ['price', 'quantity', 'tax_rate']