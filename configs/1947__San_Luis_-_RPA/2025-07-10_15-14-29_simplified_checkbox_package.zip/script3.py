for page_num, page_fields in actual_fields.items():
    for field_name, field_data in page_fields.items():
        actual = field_data['value']
        expected = expected_values.get(field_name, '')
        
        # Custom validation for currency fields
        if '$' in str(expected):
            # Remove $ and compare as numbers
            actual_num = float(actual.replace('$', ''))
            expected_num = float(str(expected).replace('$', ''))
            is_match = abs(actual_num - expected_num) < 0.01
        else:
            is_match = actual == expected
            
        if is_match:
            validation_results['matches'].append(
                create_match(field_name, expected, actual, 
                           field_data['type'], page_num, field_data['coordinates'])
            )
        else:
            validation_results['mismatches'].append(
                create_mismatch(field_name, expected, actual,
                              field_data['type'], page_num, field_data['coordinates'])
            )