form_variables = {
    "buyer1_page1": "Enter buyer name from page 1",

}


expected_values = {}
expected_values['buyer1'] = input_data["buyer1_page1"]